const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db.sqlite');

exports.handler = async function(event, context) {
  return new Promise((resolve, reject) => {
    db.all("SELECT * FROM products", (err, rows) => {
      if (err) {
        resolve({ statusCode: 500, body: JSON.stringify({ error: err.message }) });
      } else {
        resolve({ statusCode: 200, body: JSON.stringify(rows) });
      }
    });
  });
};